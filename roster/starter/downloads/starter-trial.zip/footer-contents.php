<script type="module" src="https://staffscroll.co.uk/roster/starter/assets/js/staff-scroll-utils.js"></script>
<script type="module" src="./js/staff-scroll.js"></script>

</body>

</html>